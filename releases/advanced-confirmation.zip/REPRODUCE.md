# Frozen numerical experiment

This archive contains synthetic data, not physical evidence.

Create a Python 3.12 virtual environment, install requirements-lock.txt, then run:

```sh
python main-2.py run --config experiment/config.json --output reproduced
```

The source under canon/ is the snapshot taken before training. The full web interface is available in the project, not this numerical archive. See experiment/protocol.json and artifacts.json for hashes.
